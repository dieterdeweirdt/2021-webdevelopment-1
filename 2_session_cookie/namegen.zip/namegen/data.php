<?php

$font = ["Montserrat", "Raleway", "PT Sans", "Nunito", "Noto Serif", "Fira Sans", "Dosis", "Bitter", "Open Sans", "Muli", "Oxygen", "Roboto", "Slabo 27px", "Source Sans Pro", "Roboto Slab"];

$prefix = ['insta', 'my', 'visual', 'i', 'you', 'mobile', 'drop', 'hello', 'go', 'pod', 'spoti', 'green', 'yelo', 'proxi', 'net'];
$suffix = ['gram', 'feed', 'pin', 'movie', 'tube', 'cloud', 'music', 'box', 'ly', 'fresh', 'play', 'pro', 'cast', 'fy', 'flix'];
$unavailable = ['instagram', 'imovie', 'youtube', 'icloud', 'dropbox', 'hellofresh', 'gopro', 'podcast', 'spotify', 'yeloplay', 'netflix'];
